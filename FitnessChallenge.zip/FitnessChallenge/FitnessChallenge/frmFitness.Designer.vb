﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFitness
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mnuFitness = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClearItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExitItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstWeightLoss = New System.Windows.Forms.ListBox()
        Me.picFitness = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnWeightLoss = New System.Windows.Forms.Button()
        Me.lblAverageLoss = New System.Windows.Forms.Label()
        Me.mnuFitness.SuspendLayout()
        CType(Me.picFitness, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuFitness
        '
        Me.mnuFitness.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.mnuFitness.Location = New System.Drawing.Point(0, 0)
        Me.mnuFitness.Name = "mnuFitness"
        Me.mnuFitness.Size = New System.Drawing.Size(609, 24)
        Me.mnuFitness.TabIndex = 0
        Me.mnuFitness.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClearItem, Me.mnuExitItem})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuClearItem
        '
        Me.mnuClearItem.Name = "mnuClearItem"
        Me.mnuClearItem.Size = New System.Drawing.Size(152, 22)
        Me.mnuClearItem.Text = "&Clear"
        '
        'mnuExitItem
        '
        Me.mnuExitItem.Name = "mnuExitItem"
        Me.mnuExitItem.Size = New System.Drawing.Size(152, 22)
        Me.mnuExitItem.Text = "E&xit"
        '
        'lstWeightLoss
        '
        Me.lstWeightLoss.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstWeightLoss.FormattingEnabled = True
        Me.lstWeightLoss.ItemHeight = 18
        Me.lstWeightLoss.Location = New System.Drawing.Point(364, 175)
        Me.lstWeightLoss.Name = "lstWeightLoss"
        Me.lstWeightLoss.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstWeightLoss.Size = New System.Drawing.Size(54, 148)
        Me.lstWeightLoss.TabIndex = 1
        '
        'picFitness
        '
        Me.picFitness.Image = Global.FitnessChallenge.My.Resources.Resources.Fitness
        Me.picFitness.Location = New System.Drawing.Point(3, 30)
        Me.picFitness.Name = "picFitness"
        Me.picFitness.Size = New System.Drawing.Size(215, 450)
        Me.picFitness.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFitness.TabIndex = 2
        Me.picFitness.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.DarkOrange
        Me.lblTitle.Location = New System.Drawing.Point(275, 40)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(232, 58)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Fitness Challenge" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Team Weight Loss"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnWeightLoss
        '
        Me.btnWeightLoss.BackColor = System.Drawing.Color.Orange
        Me.btnWeightLoss.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWeightLoss.Location = New System.Drawing.Point(315, 126)
        Me.btnWeightLoss.Name = "btnWeightLoss"
        Me.btnWeightLoss.Size = New System.Drawing.Size(153, 23)
        Me.btnWeightLoss.TabIndex = 4
        Me.btnWeightLoss.Text = "Enter Weight Loss"
        Me.btnWeightLoss.UseVisualStyleBackColor = False
        '
        'lblAverageLoss
        '
        Me.lblAverageLoss.AutoSize = True
        Me.lblAverageLoss.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageLoss.Location = New System.Drawing.Point(261, 356)
        Me.lblAverageLoss.Name = "lblAverageLoss"
        Me.lblAverageLoss.Size = New System.Drawing.Size(261, 18)
        Me.lblAverageLoss.TabIndex = 5
        Me.lblAverageLoss.Text = "Average weight loss for the is XX.X lbs"
        Me.lblAverageLoss.Visible = False
        '
        'frmFitness
        '
        Me.AcceptButton = Me.btnWeightLoss
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(609, 462)
        Me.Controls.Add(Me.lblAverageLoss)
        Me.Controls.Add(Me.btnWeightLoss)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picFitness)
        Me.Controls.Add(Me.lstWeightLoss)
        Me.Controls.Add(Me.mnuFitness)
        Me.MainMenuStrip = Me.mnuFitness
        Me.Name = "frmFitness"
        Me.Text = "Fitness Challenge"
        Me.mnuFitness.ResumeLayout(False)
        Me.mnuFitness.PerformLayout()
        CType(Me.picFitness, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnuFitness As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuClearItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExitItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lstWeightLoss As System.Windows.Forms.ListBox
    Friend WithEvents picFitness As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents btnWeightLoss As System.Windows.Forms.Button
    Friend WithEvents lblAverageLoss As System.Windows.Forms.Label

End Class
