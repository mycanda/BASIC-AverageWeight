﻿' Program:  Fitness Challenge
' Author:   Daniel Laird
' Date:     Nov 18th, 2015
' Purpose:  This application accepts up to 8 weight loss values.
'           After all values have been entered, it displays the
'           average weight loss for the team.


Option Strict On


Public Class frmFitness



    Private Sub btnWeightLoss_Click(sender As Object, e As EventArgs) Handles btnWeightLoss.Click
        ' This event handler accepts and displays the average weight loss
        ' for the team. 

        ' Declaration Section
        Dim strWeightLoss As String
        Dim decWeightLoss As Decimal
        Dim decAverageLoss As Decimal
        Dim decTotalWeightLoss As Decimal = 0D

        ' Input box variables
        Const strINPUT_HEADING As String = "Weight Loss"
        Dim strInputMessage As String = "Enter the weight loss for team member #"
        Const strNORMAL_MESSAGE As String = "Enter the weight loss for team member #"
        Const strNON_NUMERIC_ERROR As String _
            = "Error - Enter a number for the weight loss of the team member #"
        Const strNEGATIVE_ERROR As String _
            = "Error - Enter a positive number for the weight loss of team member #"

        ' Loop control variables
        Const intMAX_NUMBER_OF_ENTRIES As Integer = 8
        Dim intNumberOfEntries As Integer = 1
        Const strCANCEL_CLICKED As String = ""

        ' Priming Read!
        strWeightLoss = InputBox(strInputMessage & intNumberOfEntries, strINPUT_HEADING, " ")


        ' Test, Looping
        While intNumberOfEntries <= intMAX_NUMBER_OF_ENTRIES _
            And strWeightLoss <> strCANCEL_CLICKED                          'TEST
            If IsNumeric(strWeightLoss) Then                                'is it a number?
                decWeightLoss = Convert.ToDecimal(strWeightLoss)
                If decWeightLoss > 0 Then                                   'it is positive?
                    lstWeightLoss.Items.Add(decWeightLoss)                  '
                    intNumberOfEntries = intNumberOfEntries + 1             'incrementing
                    decTotalWeightLoss = decTotalWeightLoss + decWeightLoss 'accumilating
                    strInputMessage = strNORMAL_MESSAGE                     'updating the message
                Else
                    strInputMessage = strNEGATIVE_ERROR                     ' Its negative message
                End If
            Else
                strInputMessage = strNON_NUMERIC_ERROR                      ' Its not a number
            End If

            If intNumberOfEntries <= intMAX_NUMBER_OF_ENTRIES Then          'if you still have room, keep repeating
                ' Read Next!
                strWeightLoss = InputBox(strInputMessage & intNumberOfEntries, strINPUT_HEADING, " ")
            End If

        End While

        If intNumberOfEntries > 1 Then

            decAverageLoss = decTotalWeightLoss / (intNumberOfEntries - 1)
            lblAverageLoss.Text = "Average weight loss for the team is " & _
                decAverageLoss.ToString("F1") & " lbs"
            lblAverageLoss.Visible = True

        Else
            MsgBox("No weight loss values entered")
        End If

        
        btnWeightLoss.Enabled = False


    End Sub


    Private Sub mnuClearItem_Click(sender As Object, e As EventArgs) Handles mnuClearItem.Click
        ' This event handler clears the listbox, hidesn the results label, 
        ' and enables the enter weight loss button

        lstWeightLoss.Items.Clear()
        lblAverageLoss.Visible = False
        btnWeightLoss.Enabled = True

    End Sub

    Private Sub mnuExitItem_Click(sender As Object, e As EventArgs) Handles mnuExitItem.Click
        ' This event handler closes the form and exits the application
        Close()

    End Sub
End Class
